#include "MonWindow.h"
#include "iHeader.h"

wchar_t* utf8_to_utf16(const char* szFormat, ...)
{
	char szText[1024];
	va_start_end(szText, szFormat);

	int length = MultiByteToWideChar(CP_UTF8, 0, szText, -1, NULL, 0);
	wchar_t* ws = new wchar_t[length];
	MultiByteToWideChar(CP_UTF8, 0, szText, strlen(szText) + 1, ws, length);

	return ws;

}
char* utf16_to_utf8(const wchar_t* str)
{
	int length = WideCharToMultiByte(CP_UTF8, 0, str, -1, NULL, 0, NULL, NULL);
	char* s = new char[length];
	WideCharToMultiByte(CP_UTF8, 0, str, lstrlenW(str) + 1, s, length, NULL, NULL);

	return s;
}

//
//win32 ctrl box
//
#include <CommCtrl.h>
#pragma comment(lib, "imm32")
#pragma comment(lib, "ComCtl32")

extern HWND hWnd;

void initWndCtrlSystem()
{
#if 1 //6.0 or later
	InitCommonControls();
#else //4.3 or later
	INITCOMMONCONTROLSEX picce;
	picce.dwSize = sizeof(INITCOMMONCONTROLSEX);
	picce.dwICC = ICC_STANDARD_CLASSES | ICC_UPDOWN_CLASS;
	InitCommonControlseEx(&picce);
#endif


}

//=====================================================================
//Static
//=====================================================================

HWND createWndStatic(const char* str,
	int x, int y, int width, int height,
	Method_Color_Update mColor)
{
	wchar_t* s = utf8_to_utf16(str);
	HWND hwndParent = hWnd;
	HINSTANCE instanceParent = (HINSTANCE)GetWindowLong(hwndParent, GWL_HINSTANCE);
	HWND hwnd = CreateWindow(WC_STATIC, s, WS_CHILD | WS_VISIBLE | ES_CENTER,
		x, y, width, height, hwndParent, (HMENU)0, instanceParent, NULL);
	delete s;

	return hwnd;
}

//=====================================================================
//Button
//=====================================================================

HWND createWndButton(const char* str,
	int x, int y, int width, int height)
{
	wchar_t* s = utf8_to_utf16(str);
	HWND hwndParent = hWnd;
	HINSTANCE instanceParent = (HINSTANCE)GetWindowLong(hwndParent, GWL_HINSTANCE);
	HWND hwnd = CreateWindow(WC_BUTTON, s,
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		x, y, width, height, hwndParent, (HMENU)0, instanceParent, NULL);
	delete s;

	return hwnd;
}

//=====================================================================
//CheckBox
//=====================================================================

HWND createWndCheckBox(const char* str,
	int x, int y, int width, int height)
{
	wchar_t* s = utf8_to_utf16(str);
	HWND hwndParent = hWnd;
	HINSTANCE instanceParent = (HINSTANCE)GetWindowLong(hwndParent, GWL_HINSTANCE);
	HWND hwnd = CreateWindow(WC_BUTTON, s,
		WS_CHILD | WS_VISIBLE | BS_CHECKBOX,
		x, y, width, height, hwndParent, (HMENU)0, instanceParent, NULL);
	delete s;

	return hwnd;
}
bool getWndCheckBox(HWND hwnd)
{
	return SendMessage(hwnd, BM_GETCHECK, 0, 0);
}
void setWndCheckBox(HWND hwnd, bool on)
{
	SendMessage(hwnd, BM_SETCHECK, on ? BST_CHECKED : BST_UNCHECKED, 0);
}

//=====================================================================
//ComboBox
//=====================================================================

HWND createWndComboBox(const char** str, int strNum,
	int x, int y, int width, int height)
{
	HWND hwndParent = hWnd;
	HINSTANCE instanceParent = (HINSTANCE)GetWindowLong(hwndParent, GWL_HINSTANCE);
	HWND hwnd = CreateWindow(WC_COMBOBOX, NULL,
		WS_CHILD | WS_VISIBLE | WS_BORDER | CBS_DROPDOWN | CBS_HASSTRINGS,
		x, y, width, height, hwndParent, (HMENU)0, instanceParent, NULL);
	addWndComboBox(hwnd, str, strNum);
	setWndComboBox(hwnd, strNum - 1);
	return NULL;
}

void addWndComboBox(HWND hwnd, int index, const char* str)
{
	wchar_t* s = utf8_to_utf16(str);
	SendMessage(hwnd, CB_INSERTSTRING, (WPARAM)index, (LPARAM)s);
	delete s;
}
void addWndComboBox(HWND hwnd, const char** str, int strNum)
{
	for (int i = 0; i < strNum; i++)
		addWndComboBox(hwnd, i, str[i]);
}
void removeWndComboBox(HWND hwnd, int index)
{
	SendMessage(hwnd, CB_DELETESTRING, (WPARAM)index, (LPARAM)0);
}
int countWndComboBox(HWND hwnd)
{
	return SendMessage(hwnd, CB_GETCOUNT, (WPARAM)0, (LPARAM)0);
}
int indexWndComboBox(HWND hwnd)
{
	return SendMessage(hwnd, CB_GETCURSEL, (WPARAM)0, (LPARAM)0);

}
char* getWndComboBox(HWND hwnd, int index)
{
	wchar_t wstr[128];
	SendMessage(hwnd, CB_GETLBTEXT, index, (LPARAM)wstr);
	return utf16_to_utf8(wstr);
}

void setWndComboBox(HWND hwnd, int index)
{
	SendMessage(hwnd, CB_SETCURSEL, (WPARAM)index, (LPARAM)0);
}

//=====================================================================
//List
//=====================================================================

HWND createWndListBox(const char** str, int strNum,
	int x, int y, int width, int height)
{
	HWND hwndParent = hWnd;
	HINSTANCE instanceParent = (HINSTANCE)GetWindowLong(hwndParent, GWL_HINSTANCE);
	HWND hwnd = CreateWindow(WC_LISTBOX, NULL,
		WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY | WS_HSCROLL | WS_VSCROLL,
		x, y, width, height, hwndParent, (HMENU)0, instanceParent, NULL);
	addWndListBox(hwnd, str, strNum);
	setWndListBox(hwnd, strNum - 1);

	return hwnd;
}

void addWndListBox(HWND hwnd, int index, const char* str)
{
	wchar_t* s = utf8_to_utf16(str);
	SendMessage(hwnd, LB_INSERTSTRING, (WPARAM)index, (LPARAM)s);
	delete s;
}

void addWndListBox(HWND hwnd, const char** str, int strNum)
{
	for (int i = 0; i < strNum; i++)
		addWndListBox(hwnd, i, str[i]);
}	
void removeWndListBox(HWND hwnd, int index)
{
	SendMessage(hwnd, LB_DELETESTRING, (WPARAM)index, (LPARAM)0);
}
int countWndListBox(HWND hwnd)
{
	return SendMessage(hwnd, LB_GETCOUNT, (WPARAM)0, (LPARAM)0);
}
int indexWndListBox(HWND hwnd)
{
	return SendMessage(hwnd, LB_GETCURSEL, (WPARAM)0, (LPARAM)0);
}
char* getWndListBox(HWND hwnd, int index)
{
	wchar_t wstr[128];
	SendMessage(hwnd, LB_GETTEXT, index, (LPARAM)wstr);
	return utf16_to_utf8(wstr);
}
void setWndListBox(HWND hwnd, int index)
{
	SendMessage(hwnd, LB_SETCURSEL, (WPARAM)index, (LPARAM)0);
}


//=====================================================================
//Radio
//=====================================================================

HWND createWndRadio(const char* str,
	int x, int y, int width, int height)
{
	wchar_t* s = utf8_to_utf16(str);
	HWND hwndParent = hWnd;
	HINSTANCE instanceParent = (HINSTANCE)GetWindowLong(hwndParent, GWL_HINSTANCE);
	HWND hwnd = CreateWindow(WC_BUTTON, s,
		WS_CHILD | WS_VISIBLE | BS_RADIOBUTTON,
		x, y, width, height, hwndParent, (HMENU)0, instanceParent, NULL);
	
	delete s;

	return hwnd;
}
bool getWndRadio(HWND hwnd)
{
	return SendMessage(hwnd, BM_GETCHECK, 0, 0);
}
void setWndRadio(HWND hwnd, bool on)
{
	SendMessage(hwnd, BM_SETCHECK, on ? BST_CHECKED : BST_UNCHECKED, 0);
}

//=====================================================================
//GroupBox
//=====================================================================

HWND createWndGroupBox(const char* str,
	int x, int y, int width, int height)
{
	wchar_t* s = utf8_to_utf16(str);
	HWND hwndParent = hWnd;
	HINSTANCE instanceParent = (HINSTANCE)GetWindowLong(hwndParent, GWL_HINSTANCE);
	HWND hwnd = CreateWindow(WC_BUTTON, s,
		WS_CHILD | WS_VISIBLE | BS_GROUPBOX,
		x, y, width, height, hwndParent, (HMENU)0, instanceParent, NULL);

	delete s;

	return hwnd;
}

//=====================================================================
//EditBox
//=====================================================================

HWND createWndEditBox(const char* str,
	int x, int y, int width, int height,
	WndEditStyle style)
{

}

HWND createWndEditBoxMultiLine(const char* str,
	int x, int y, int width, int height)
{

}