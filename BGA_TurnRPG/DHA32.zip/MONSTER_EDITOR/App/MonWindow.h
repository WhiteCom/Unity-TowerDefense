#pragma once

// Windows 헤더 파일
#include <windows.h>

wchar_t* utf8_to_utf16(const char* szFormat, ...);
char* utf16_to_utf8(const wchar_t* str);

void initWndCtrlSystem();

typedef HBRUSH(*Method_Color_Update)(WPARAM wParam, LPARAM lParam);

//
//Static
//

HWND createWndStatic(const char* str, 
	int x, int y, int width, int height, 
	Method_Color_Update mColor);

//
//Button
//

HWND createWndButton(const char* str,
	int x, int y, int width, int height);

//
//Check
//

HWND createWndCheckBox(const char* str,
	int x, int y, int width, int height);
bool getWndCheckBox(HWND hwnd);
void setWndCheckBox(HWND hwnd, bool on);

//
//Combo
//

HWND createWndComboBox(const char** str, int strNum,
	int x, int y, int width, int height);
void addWndComboBox(HWND hwnd, int index, const char* str);
void addWndComboBox(HWND hwnd, const char** str, int strNum);
void removeWndComboBox(HWND hwnd, int index);
int countWndComboBox(HWND hwnd);
int indexWndComboBox(HWND hwnd);
char* getWndComboBox(HWND hwnd, int index);
void setWndComboBox(HWND hwnd, int index);

//
//List
//

HWND createWndListBox(const char** str, int strNum,
	int x, int y, int width, int height);
void addWndListBox(HWND hwnd, int index, const char* str);
void addWndListBox(HWND hwnd, const char** str, int strNum);
void removeWndListBox(HWND hwnd, int index);
int countWndListBox(HWND hwnd);
int indexWndListBox(HWND hwnd);
char* getWndListBox(HWND hwnd, int index);
void setWndListBox(HWND hwnd, int index);

//
//Radio
//

HWND createWndRadio(const char* str,
	int x, int y, int width, int height);
bool getWndRadio(HWND hwnd);
void setWndRadio(HWND hwnd, bool on);

//
//Group
//

HWND createWndGroupBox(const char* str, 
	int x, int y, int width, int height);

enum WndEditStyle {
	WndEditAll = 0,
	WndEditInt,
	WndEditFloat
};

//
//Editor
//

HWND createWndEditBox(const char* str,
	int x, int y, int width, int height,
	WndEditStyle style);

HWND createWndEditBoxMultiLine(const char* str,
	int x, int y, int width, int height);

