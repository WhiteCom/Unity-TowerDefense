#include "Monster.h"

iArray* arrayMonster;


