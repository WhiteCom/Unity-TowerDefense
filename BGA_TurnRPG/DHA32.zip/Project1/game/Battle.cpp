#include "Battle.h"

#include "Loading.h"
#include "Stage.h"
#include "Ending.h"

//================================================================
// Battle.cpp
//================================================================

Texture* texBg;

BattleManager* bm;

void loadBattle()
{
	bm = new BattleManager();

	texBg = createImage("assets/Image/BattleBg/옥좌.bmp");

	createBattlePopTopUI();
	createBattlePopBottomUI();

	showBattlePopTopUI(true);
	showBattlePopBottomUI(true);
}

void freeBattle()
{
	delete bm;
}

void drawBattle(float dt)
{
	//
	//drawBg
	//
	//현재 Bg Image 320 x 240 
	float rateX = devSize.width / texBg->width;
	float rateY = devSize.height / texBg->height;
	drawImage(texBg, 0, 0, TOP | LEFT,
		0, 0, texBg->width, texBg->height, rateX, rateY, 2, 0);

	//
	//draw unit(monster, hero)
	//
	bm->paint(dt);

	//
	//draw popUp
	//

	drawBattlePopTopUI(dt, iPointZero);
	drawBattlePopBottomUI(dt, iPointZero);
}

bool keyBattle(iKeyStat stat, iPoint point)
{
	if (keyBattlePopTopUI(stat, point))
		return false;

	switch (stat)
	{
	case iKeyStatBegan:
#if 1 //test code
		setLoading(gs_stage, freeBattle, loadStage);
#endif
		break;

	case iKeyStatMoved:
		break;

	case iKeyStatEnded:
		break;
	}
	return true;
}


//========================================================
// popTopUI : playTime, Btn(Menu, Inven, Option)
//========================================================


void createBattlePopTopUI()
{

}
void freeBattlePopTopUI()
{

}
void showBattlePopTopUI(bool show)
{

}
void drawBattlePopTopUI(float dt, iPoint off)
{

}
bool keyBattlePopTopUI(iKeyStat stat, iPoint point)
{
	return false;
}

//========================================================
// popBottomUI 
//========================================================
iPopup* popBottomUIStatus; //전투메뉴
iStrTex** imgBottomUIStatus; //Enemy, Hero
iImage** imgHeroGuage; 

Texture* texEnemyStat(const char* str);
Texture* texHeroStat(const char* str);

void drawBattlePopBefore(iPopup* pop, float dt, float rate);
void drawBattlePopAfter(iPopup* pop, float dt, float rate);

void createBattlePopBottomUI()
{
	iImage* img;
	Texture* tex;
	iPopup* pop;
	imgBottomUIStatus = new iStrTex * [MAX_ENEMY + MAX_HERO];
	imgHeroGuage = new iImage * [10 * MAX_HERO];
	int statIndex = 0;

	//
	//Total Bg
	//
	pop = new iPopup();
	iGraphics* g = iGraphics::share();
	iSize size = iSizeMake(1000, 300);
	iPoint BgOff = iPointMake(devSize.width / 2 - 500, devSize.height / 2 + 50);
	g->init(size);
	
	setRGBA(0.5f, 0.5f, 0.5f, 0.5f);
	g->fillRect(0,0,size.width, size.height, 10);

	tex = g->getTexture();
	img = new iImage();
	img->addObject(tex);
	freeImage(tex);
	
	pop->addObject(img);


	//
	// EnemyStatusBg
	//
	iPoint MenuBgOff = iPointMake(40, 30);

	size = iSizeMake(320, 240);
	g->init(size);

	setRGBA(1, 1, 1, 1.0f);
	g->drawRect(0, 0, size.width, size.height, 10);
	setRGBA(0.2f, 0.2f, 0.2f, 0.8f);
	g->fillRect(0, 0, size.width, size.height, 10);
	setRGBA(1, 1, 1, 1);
	tex = g->getTexture();

	img = new iImage();
	img->addObject(tex);
	freeImage(tex);
	img->position = MenuBgOff;
	pop->addObject(img);
	
	//
	// EnemyStatus
	//

	size = iSizeMake(100, 60);

	const char* stBottomEnemy[4] = {"적1", "적2", "적3", "적4"};
	

	for (int i = 0; i < bm->enemyNum; i++)
	{
		iStrTex* stStat = new iStrTex(texEnemyStat); //name, HP, MP
		stStat->setString("[%s] %s : %d",
			stBottomEnemy[i], "HP", bm->enemy[i]->hp);
		
		img = new iImage();
		img->addObject(stStat->tex);
		img->position = MenuBgOff + iPointMake(0, 50*i);
		pop->addObject(img);
		imgBottomUIStatus[statIndex] = stStat;
		statIndex++;
	}

	//
	// HeroStatusBg
	//
	iPoint StatBgOff = iPointMake(400, 30); //80 + 320

	size = iSizeMake(560, 240);
	g->init(size);

	setRGBA(1, 1, 1, 1);
	g->drawRect(0, 0, size.width, size.height, 10);
	setRGBA(0.2f, 0.2f, 0.2f, 0.8f);
	g->fillRect(0, 0, size.width, size.height, 10);

	tex = g->getTexture();
	img = new iImage();
	img->addObject(tex);
	freeImage(tex);
	img->position = StatBgOff;
	pop->addObject(img);

	//
	// HeroStat
	//
	const char* stBottomHero[4] = { "영웅1", "영웅2", "영웅3", "영웅4" };
	const char* stat[2] = { "HP", "MP" };
	
//#need update! if change bm->hero
	for (int i = 0; i < bm->heroNum; i++)
	{
		//
		//str
		//
		iStrTex* stStat = new iStrTex(texHeroStat); //name, HP, MP
		stStat->setString("[%s]  %s : %d / %s : %d",
			stBottomHero[i], stat[0], bm->hero[i]->hp, stat[1], 0);
		
		img = new iImage();
		img->addObject(stStat->tex);
		img->position = StatBgOff + iPointMake(0, 50*i);
		pop->addObject(img);
		imgBottomUIStatus[statIndex] = stStat;
		statIndex++;
		
		// 
		// guage Bg
		//
		iPoint gp = StatBgOff + iPointMake(423, 25 + 50 * i);
		size = iSizeMake(100, 25);
		g->init(size);

		setRGBA(0, 0, 0, 1);
		//g->fillRect(423, 25, 102, 25, 5);
		g->fillRect(0, 0, size.width, size.height, 5);
		tex = g->getTexture();
		img = new iImage();
		img->addObject(tex);
		freeImage(tex);
		img->position = gp;
		pop->addObject(img);

		//
		// guage : 10등분 해서, att/_att 비율에 따른 값에 해당하는 인덱스값 만큼 활성화 시키기. 
		//
		for (int j = 0; j < 10; j++)
		{
			img = new iImage();
			for (int k = 0; k < 2; k++)
			{
				size = iSizeMake(8, 25);
				g->init(size);
				if (k == 0) setRGBA(0, 0, 0, 0);
				else		setRGBA(0, 1, 0, 1);
				g->fillRect(0,0,size.width, size.height,3);
				setRGBA(1, 1, 1, 1);

				tex = g->getTexture();
				img->addObject(tex);
				freeImage(tex);
			}
			img->position = gp + iPointMake(1 + 10 * j, 0);
			pop->addObject(img);
			imgHeroGuage[i * 10 + j] = img;
		}
	}

	pop->methodBefore = drawBattlePopBefore;
	pop->methodAfter = drawBattlePopAfter;
	pop->openPoint = BgOff;
	pop->closePoint = BgOff;

	popBottomUIStatus = pop;
}
void freeBattlePopBottomUI()
{
	delete popBottomUIStatus;
	for (int i = 0; i < MAX_ENEMY + MAX_HERO; i++)
		delete imgBottomUIStatus[i];
	delete imgBottomUIStatus;

	for (int i = 0; i < 10 * MAX_HERO; i++)
		delete imgHeroGuage[i];
	delete imgHeroGuage;
}

Texture* texEnemyStat(const char* str)
{
	iGraphics* g = iGraphics::share();
	iSize size = iSizeMake(320, 50);
	g->init(size);

	setStringSize(28);
	setStringRGBA(1, 1, 1, 1);
	g->drawString(25, 25, TOP | LEFT, str);

	return g->getTexture();
}

Texture* texHeroStat(const char* str)
{
	iGraphics* g = iGraphics::share();
	iSize size = iSizeMake(600, 50);
	g->init(size);

	setStringSize(28);
	setStringRGBA(1, 1, 1, 1);
	g->drawString(25, 25, TOP | LEFT, str);


	
	return g->getTexture();
}

static float HeroRate = 0.0f;
void drawBattlePopBefore(iPopup* pop, float dt, float rate)
{
	//
	//hero Guage Check
	//
	for (int j = 0; j < bm->heroNum; j++)
	{
		for (int i = 0; i < 10; i++)
		{
//#issue! 공격하려는 attDt 비율대로 못그리겠음.
			//float rate = bm->hero[j]->attDt / bm->hero[j]->_attDt;
			//rate = rate * 10; //0 ~ 10;
			HeroRate;
			//imgHeroGuage[j * 10 + i]->setTexObject(i == (int)HeroRate * 10);
			imgHeroGuage[j * 10 + i]->setTexObject(i >= ((int)HeroRate*10) ? 0 : 1);
		}
	}
}

void drawBattlePopAfter(iPopup* pop, float dt, float rate)
{
	//2 3 4 5 : enemy
	//7 8 9 10 : hero
	const char* stBottomEnemy[4] = { "적1", "적2", "적3", "적4" };
	const char* stBottomHero[4] = { "영웅1", "영웅2", "영웅3", "영웅4" };
	const char* stat[2] = { "HP", "MP" };

	for (int i = 0; i < MAX_ENEMY; i++)
		imgBottomUIStatus[i]->setString("[%s] %s : %d ", stBottomEnemy[i], stat[0], bm->enemy[i]->hp);

	for (int i = 0; i < MAX_HERO; i++)
		imgBottomUIStatus[i+MAX_ENEMY]->setString("[%s]  %s : %d / %s : %d", stBottomHero[i], stat[0], bm->hero[i]->hp, stat[1], 0);
	
	

}

void showBattlePopBottomUI(bool show)
{
	popBottomUIStatus->show(show);
	if (show)
	{
	}
	else
	{

	}
}
void drawBattlePopBottomUI(float dt, iPoint off)
{
	popBottomUIStatus->paint(dt);
}


//================================================================
// BattleUnit, Monster, Hero
//================================================================

//================================================================
//BattleUnit
//================================================================

#define MAX_HP 100
#define MAX_AP 10

BattleUnit::BattleUnit(int index)
{
	this->index = index;
	imgs = NULL;
	imgCurr = NULL;
	BuPop = NULL;
	be = BeWait;
	imgIndex = 0;
	imgNum = 0;
	position = iPointZero;
	hp = MAX_HP;
	atk = MAX_AP;

	attAniDt = _attAniDt = 0.0f;
	attDt = 0.0f;
	_attDt = 0.0f;
	target = NULL;
	attacking = false;
	state = 0;
}

BattleUnit::~BattleUnit()
{
	if (imgs == NULL)
		return;

	for (int i = 0; i < imgNum; i++)
		delete imgs[i];
	delete imgs;
}

float BattleUnit::update(float dt)
{
#if 0
	attDt += dt;
	if (attDt >= _attDt)
	{
		return (attDt - _attDt) / _attDt;
	}
	//return attDt / _attDt;
	return 0.0f;
#else

	//#issue! turn process problem
	attDt += dt;
	HeroRate = attDt / _attDt;
	return attDt / _attDt;
#endif

}

bool BattleUnit::paint(float dt, iPoint off)
{
	//imgCurr->paint(dt, position + off, iPointMake(1, 1));
	imgCurr->paint(dt, position + off, iPointMake(1, 1));

	if (hp == 0)
		return true;
	else
		return false;
}

void BattleUnit::attack()
{
	//attDt -= _attDt;
	//be = BeAttack;
	//imgCurr = imgs[BeAttack];
	attDt = 0.0f;
	_position = position;
}

//================================================================
// BUMonster
//================================================================

BUMonster::BUMonster(int index) : BattleUnit(index)
{
	const char* path[2][5] = {
		{
			"assets/Image/Monster/[Z] (異) 요우무.bmp",
			"assets/Image/Monster/[Z] (異) 요우무 Ct.bmp",
			"assets/Image/Monster/[Z] (異) 요우무 Ct.2.bmp",
			"assets/Image/Monster/[Z] (異) 요우무 M.Sl(4).bmp",
			"assets/Image/Monster/[Z] (異) 요우무.bmp"
		},
		{
			"assets/Image/Monster/[Z] (異) 요우무.bmp",
			"assets/Image/Monster/[Z] (異) 요우무 Ct.bmp",
			"assets/Image/Monster/[Z] (異) 요우무 Ct.2.bmp",
			"assets/Image/Monster/[Z] (異) 요우무 M.Sl(4).bmp",
			"assets/Image/Monster/[Z] (異) 요우무.bmp"
		},
	};
	imgs = new iImage * [BehaveNum];
	for (int i = 0; i < BehaveNum; i++)
	{
		Texture* tex = createImageAlpha(path[index][i]);
		iImage* img = new iImage();
		img->addObject(tex);
		freeImage(tex);

		imgs[BeWait + i] = img;
	}
	imgNum = BehaveNum;
	be = BeWait;
	imgCurr = imgs[BeWait];

	float attackDt[2] = {
		3.0f, 5.0f
	};
	_attAniDt = attackDt[index];
	_attDt = ENEMY_COOL_TIME;
}

BUMonster::~BUMonster()
{

}

float BUMonster::update(float dt)
{
	//to do...(버퍼)

	return BattleUnit::update(dt);
}

bool BUMonster::paint(float dt, iPoint off)
{
	float atkTime = 0.0f;
	atkTime += dt;

	iPoint tp = iPointZero;
	iPoint tp2 = iPointZero;

	float imgW = imgCurr->tex->width;
	float imgH = imgCurr->tex->height;
	iPoint center = off + iPointMake(-imgW / 2, -imgH / 2);


	//bool dead = BattleUnit::paint(dt, center + tp);
	bool dead = false; //default;

#if 1
	if (target && attacking)
	{
		//move
		if (state == 0)
		{
			attAniDt += dt;

			if (attAniDt >= ENEMY_MOVE_TIME)
			{
				attAniDt = ENEMY_MOVE_TIME;
				imgCurr = imgs[BeWait];
				attAniDt = 0.0f;
				state = 1;
			}
			iPoint tmp = target->position - position - iPointMake(50, 0);
			tp = easeIn(attAniDt / ENEMY_MOVE_TIME, position - position, tmp);

			dead = BattleUnit::paint(dt, center + tp);

			return dead;
		}

		//attack
		else if (state == 1)
		{
			attAniDt += dt;

			if (attAniDt >= ENEMY_ATK_TIME)
			{
				attAniDt = ENEMY_ATK_TIME;
				imgCurr = imgs[BeWait];
				attAniDt = 0.0f;
				state = 2;
				target->hp -= atk;
				if (target->hp < 0)
					target->hp = 0;
			}
			else if (attAniDt >= ENEMY_ATK_TIME / 2)
			{
				imgCurr = imgs[BeAttack];
			}

			iPoint tmp = target->position - position - iPointMake(50, 0);
			tp = linear(attAniDt / (ENEMY_ATK_TIME), tmp, tmp);

			dead = BattleUnit::paint(dt, center + tp);

			return dead;
		}

		//back
		else if (state == 2)
		{
			attAniDt += dt;

			if (attAniDt >= ENEMY_BACK_TIME)
			{
				attAniDt = ENEMY_BACK_TIME;
				imgCurr = imgs[BeWait];
				state = 0;
				attAniDt = 0.0f;
				bm->attacking = false;
				attacking = false;
				//공격이후 자기 자리로 돌아옴.
			}
			iPoint tmp = target->position - position - iPointMake(50, 0);
			//tp = linear(attDt / (ENEMY_BACK_TIME), tmp, position - position);
			tp = easeIn(attAniDt / (ENEMY_BACK_TIME), tmp, position - position);

			dead = BattleUnit::paint(dt, center + tp);

			return dead;
		}
	}

	else
	{
		dead = BattleUnit::paint(dt, center);
		//#need update! add tp position
		state = 0;
		attAniDt = 0.0f;

		return dead;
	}
#endif

	//공격 이후

	//overlay...drawing;;;


	return dead;
}

void BUMonster::attack()
{
	//to do...
	//맞는 놈 선택 
	if (index == 0)
	{
		//체력 가장 높은놈...
	}
	else if (index == 1)
	{
		//공격력 가장 높은 놈...
	}
	else if (index == 2)
	{
		//한 놈만 패는 놈
	}

	if(bm->heroNum > 0)
		target = (BattleUnit*)bm->hero[random() % bm->heroNum];

	BattleUnit::attack();
}

//================================================================
// BUHero
//================================================================

BUHero::BUHero(int index) : BattleUnit(index)
{
	const char* path[2][5] = {
			{
				"assets/Image/Monster/[Z] (異) 사쿠야.bmp",
				"assets/Image/Monster/[Z] (異) 사쿠야 (2).bmp",
				"assets/Image/Monster/[Z] (異) 사쿠야 (3).bmp",
				"assets/Image/Monster/[Z] (異) 사쿠야 (2).bmp",
				"assets/Image/Monster/[Z] (異) 사쿠야 (2).bmp",
			},
			{
				"assets/Image/Monster/[Z] (異) 사쿠야.bmp",
				"assets/Image/Monster/[Z] (異) 사쿠야 (2).bmp",
				"assets/Image/Monster/[Z] (異) 사쿠야 (3).bmp",
				"assets/Image/Monster/[Z] (異) 사쿠야 (2).bmp",
				"assets/Image/Monster/[Z] (異) 사쿠야 (2).bmp",
			},
	};
	imgs = new iImage * [BehaveNum];
	for (int i = 0; i < BehaveNum; i++)
	{
		Texture* tex = createImageAlpha(path[index][i]);
		iImage* img = new iImage();
		img->reverse = REVERSE_WIDTH;
		img->addObject(tex);
		freeImage(tex);

		imgs[BeWait + i] = img;
	}
	imgNum = BehaveNum;
	be = BeWait;
	imgCurr = imgs[BeWait];

	float attackDt[2] = {
		3.0f, 5.0f
	};
	_attAniDt = attackDt[index];
	_attDt = HERO_COOL_TIME;

	enemyIndex = -1;
}

BUHero::~BUHero()
{

}

float BUHero::update(float dt)
{
	//to do...
	//printf("Hero Time\n");
	return BattleUnit::update(dt);
}

bool BUHero::paint(float dt, iPoint off)
{
	float atkTime = 0.0f;

	iPoint tp = iPointZero;

	//bool dead = BattleUnit::paint(dt, center + tp);
	bool dead = false; //default;

	float imgW = imgCurr->tex->width;
	float imgH = imgCurr->tex->height;
	iPoint center = off + iPointMake(-imgW / 2, -imgH / 2);

#if 1
	if (target && attacking)
	{
		//move
		if (state == 0)
		{
			attAniDt += dt;

			if (attAniDt >= HERO_MOVE_TIME)
			{
				attAniDt = HERO_MOVE_TIME;
				//imgCurr = imgs[BeAttack];
				imgCurr = imgs[BeWait];
				attAniDt = 0.0f;
				state = 1;
			}
			iPoint tmp = target->position - position - iPointMake(-50, 0);
			//tp = linear(attDt / HERO_MOVE_TIME, position - position, tmp);
			tp = easeIn(attAniDt / HERO_MOVE_TIME, position - position, tmp);

			dead = BattleUnit::paint(dt, center + tp);

			return dead;
		}

		//attack
		else if (state == 1)
		{
			attAniDt += dt;

			if (attAniDt >= HERO_ATK_TIME)
			{
				attAniDt = HERO_ATK_TIME;
				imgCurr = imgs[BeWait];
				attAniDt = 0.0f;
				state = 2;
				target->hp -= atk;
				if (target->hp < 0)
					target->hp = 0;
			}
			else if (attAniDt >= HERO_ATK_TIME / 2)
			{
				imgCurr = imgs[BeAttack];
			}
			iPoint tmp = target->position - position - iPointMake(-50, 0);
			tp = linear(attAniDt / (HERO_ATK_TIME), tmp, tmp);

			dead = BattleUnit::paint(dt, center + tp);

			return dead;
		}

		//back
		//공격이후 자기 자리로 돌아옴.
		else if (state == 2)
		{
			attAniDt += dt;

			if (attAniDt >= HERO_BACK_TIME)
			{
				attAniDt = HERO_BACK_TIME;
				imgCurr = imgs[BeWait];
				state = 0;
				attAniDt = 0.0f;
				bm->attacking = false;
				attacking = false;
			}
			iPoint tmp = target->position - position - iPointMake(-50, 0);
			//tp = linear(attDt / (HERO_BACK_TIME), tmp, position - position);
			tp = easeIn(attAniDt / (HERO_BACK_TIME), tmp, position - position);

			dead = BattleUnit::paint(dt, center + tp);

			return dead;
		}
	}

	else
	{
		dead = BattleUnit::paint(dt, center);
		//#need update! add tp position
		state = 0;
		attAniDt = 0.0f;

		return dead;
	}
#endif

	//그려줄거 다 그려준 후

	//overlay...drawing;;;
	//if(enemyIndex == -1)
	//{
	// 화살표
	//}

	return dead;
}

void BUHero::attack()
{
	//to do...
	//맞는 놈 선택 

	//키 처리 대기중
	//if(enemyIndex == -1)
	//{
	//	//ui에서 때리는 놈 지정 대기 상태
	//}
	//else

	if (bm->enemyNum > 0)
		target = (BattleUnit*)bm->enemy[random() % bm->enemyNum];

	BattleUnit::attack();
}

void BUHero::keyHero(iKeyStat stat, iPoint p)
{
	
}

//================================================================
// BattleManager
//================================================================

BattleManager::BattleManager()
{
	_enemyNum = MAX_ENEMY;
	_heroNum = MAX_HERO;

	//enemyNum = (random() % _enemyNum) + 1;
	//heroNum = (random() % _heroNum) + 1;
	heroNum = _heroNum;
	enemyNum = _enemyNum;

#if 1
	int enemyType = 0;
	int heroType = 0;
	enemy = new BUMonster * [enemyNum];
	for (int i = 0; i < enemyNum; i++)
	{
		int type = 0;
		enemy[i] = new BUMonster(type);
	}

	hero = new BUHero * [heroNum];
	for (int i = 0; i < heroNum; i++)
	{
		int type = 0;
		hero[i] = new BUHero(type);
	}

#endif

	attacking = false;
}
BattleManager::~BattleManager()
{
	for (int i = 0; i < enemyNum; i++)
		delete enemy[i];
	delete enemy;

	for (int i = 0; i < heroNum; i++)
		delete hero[i];
	delete hero;
}

void BattleManager::paint(float dt)
{
	//iPoint off = iPointZero;
	iPoint off = iPointMake(devSize.width / 2, devSize.height / 2 - 120);

	int i;

	//
	//Enemy
	//
	for (i = 0; i < enemyNum; i++)
	{
#if 1
		iPoint ep;
		int offWidth = -250;
		if (enemyNum == 1)
			ep = iPointMake(-250, 0);
		else if (enemyNum == 2)
		{
			if (i == 0)			ep = iPointMake(offWidth, -40);
			else				ep = iPointMake(offWidth, 40);
		}
		else if (enemyNum == 3)
		{
			if (i == 0)			ep = iPointMake(offWidth, -80);
			else if (i == 1)	ep = iPointMake(offWidth, 0);
			else				ep = iPointMake(offWidth, 80);
		}
		else if (enemyNum == 4)
		{
			if (i == 0)			ep = iPointMake(offWidth, -120);
			else if (i == 1)	ep = iPointMake(offWidth, -40);
			else if (i == 2)	ep = iPointMake(offWidth, 40);
			else				ep = iPointMake(offWidth, 120);
		}
		else
			ep = iPointZero;
#endif
		enemy[i]->position = off + ep;
		if (enemy[i]->paint(dt, iPointZero))
		{
			enemyNum--;
			enemy[i] = enemy[enemyNum];
			i--;
		}
	}

	//
	//Hero
	//

	for (i = 0; i < heroNum; i++)
	{

#if 1
		iPoint ep;
		int offWidth = 250;
		if (heroNum == 1)
			ep = iPointMake(250, 0);
		else if (heroNum == 2)
		{
			if (i == 0)			ep = iPointMake(offWidth, -40);
			else				ep = iPointMake(offWidth, 40);
		}
		else if (heroNum == 3)
		{
			if (i == 0)			ep = iPointMake(offWidth, -80);
			else if (i == 1)	ep = iPointMake(offWidth, 0);
			else				ep = iPointMake(offWidth, 80);
		}
		else if (heroNum == 4)
		{
			if (i == 0)			ep = iPointMake(offWidth, -120);
			else if (i == 1)	ep = iPointMake(offWidth, -40);
			else if (i == 2)	ep = iPointMake(offWidth, 40);
			else				ep = iPointMake(offWidth, 120);
		}
		else
			ep = iPointZero;
#endif
		hero[i]->position = off + ep;
		if (hero[i]->paint(dt, iPointZero))
		{
			heroNum--;
			hero[i] = hero[heroNum];
			i--;
		}
	}


	if (enemyNum == 0)
	{
		//win
		printf("전투승리!\n");

		//to do... 승리 팝업
		setLoading(gs_stage, freeBattle, loadStage);
	}

	else if (heroNum == 0)
	{
		//lose
		printf("전투패배!\n");

		//to do... 패배 팝업
		setLoading(gs_ending, freeBattle, loadEnding);
	}

	if (attacking)
		return;

	BattleUnit* bu = NULL;
	float attRate = 0.0f;
	float t = 0.0f;

	//#issue! attRate, t 처리

	//key 처리
#if 1
	for (i = 0; i < heroNum; i++)
	{
		t = hero[i]->update(dt);
		HeroRate = t;
		if (attRate < t)
		{
			bu = hero[i];
			attRate = t;
		}
	}
#endif
	for (i = 0; i < enemyNum; i++)
	{
		t = enemy[i]->update(dt);
		if (attRate < t)
		{
			bu = enemy[i];
			attRate = t;
		}
	}

	if (bu)
	{
		bu->attack();
		attacking = true;
		bu->attacking = true;
#if 1
		//#need update! 엄격히 따지면 여기서 처리할 문장은 아님.
		bu->attDt = 0.0f;
#endif
	}
}

