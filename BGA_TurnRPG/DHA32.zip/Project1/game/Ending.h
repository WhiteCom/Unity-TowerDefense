#pragma once

#include "iStd.h"

void loadEnding();
void drawEnding(float dt);
void freeEnding();
void keyEnding(iKeyStat stat, iPoint point);