#pragma once

#define MAP_FILE_SIZE 2048

#define TILE_W		16
#define TILE_H		12
#define TILE_WSIZE	32
#define TILE_HSIZE	32

#define INF			99
