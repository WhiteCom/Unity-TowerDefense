

#include "MONSTER_EDITOR.h"

#define MAX_LOADSTRING 100

HBRUSH updateColor(WPARAM wParam, LPARAM lParam);

bool runWnd;
HWND hWnd;

HINSTANCE hInst;                                
WCHAR szTitle[MAX_LOADSTRING];                  
WCHAR szWindowClass[MAX_LOADSTRING];            

// 이 코드 모듈에 포함된 함수의 선언을 전달합니다:
ATOM                MyRegisterClass(HINSTANCE hInstance);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 여기에 코드를 입력합니다.

    // 전역 문자열을 초기화합니다.
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_MONSTEREDITOR, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 애플리케이션 초기화를 수행합니다:
    hInst = hInstance; // 인스턴스 핸들을 전역 변수에 저장합니다.

    hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, 1024, 720, nullptr, nullptr, hInstance, nullptr);

    if (hWnd == NULL)
    {
        return FALSE;
    }

    ShowWindow(hWnd, nCmdShow);
#if 0
    UpdateWindow(hWnd);
#else
    updateWindow();
#endif

    initWndCtrlSystem();
    DragAcceptFiles(hWnd, TRUE);

    initMonEditor();
    /*
    hWndStatic = createWndStatic("Test", 0, 0, 100, 50, NULL);

    hWndBtn = createWndButton("B1", 100, 50, 100, 30);
    */

    MSG msg;

    runWnd = true;

    // 기본 메시지 루프입니다:
    while (runWnd)
    {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else
        {
            //to do...
        }
    }

    return (int) msg.wParam;
}


//
//  함수: MyRegisterClass()
//
//  용도: 창 클래스를 등록합니다.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MONSTEREDITOR));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_MONSTEREDITOR);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

iSize sizeMonitor;
static int win_border_width = 0, win_border_height = 0;

void updateWindow()
{
    //Initialize window positon to CenterView
    RECT rect;
    GetWindowRect(hWnd, &rect);

    int w = rect.right - rect.left;
    int h = rect.bottom - rect.top;
    int x = (sizeMonitor.width - w) / 2;
    int y = (sizeMonitor.height - h) / 2;

    SetWindowPos(hWnd, HWND_TOP,
        x, y, w + win_border_width, h + win_border_height, SWP_SHOWWINDOW);
}



LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_CREATE:
    {
        sizeMonitor = iSizeMake(GetSystemMetrics(SM_CXSCREEN),
                                GetSystemMetrics(SM_CYSCREEN));
#ifdef _DEBUG
        printf("monitor : %.f, %.f\n", sizeMonitor.width, sizeMonitor.height);
#endif
        RECT rt;
        GetWindowRect(hWnd, &rt); printf("wrt : %d %d %d\n", rt.left, rt.top, rt.right, rt.left);
        RECT rtWnd = rt;
        GetClientRect(hWnd, &rt); printf("crt : %d %d %d\n", rt.left, rt.top, rt.right, rt.left);
        win_border_width = (rtWnd.right - rtWnd.left) - (rt.right - rt.left);
        win_border_height = (rtWnd.bottom - rtWnd.top) - (rt.bottom - rt.top);

        GetSystemMetrics(SM_CXFRAME) * 2;
        GetSystemMetrics(SM_CYFRAME) * 2;
        GetSystemMetrics(SM_CYFRAME) * 2 + GetSystemMetrics(SM_CYCAPTION);
            
        break;
    }
    case WM_COMMAND:
        {
        updateMonster(wParam, lParam);
        break;
        }
    
    case WM_CLOSE:
    {
        
        const char* quitText[3] = {
            "종료하시겠습니까?",
            "Are you quit?",
            "syuuro deska?"
        };

        enum language
        {
            Korean = 0,
            English,
            Japanese,
        };

        int lang = English;
        wchar_t* title0 = utf8_to_utf16(quitText[lang]);
        const wchar_t* title1 = L"Quit";

        if (MessageBox(NULL, title0, title1, MB_YESNO) == IDYES)
        {
            runWnd = false;
        }

        delete title0;
        return 0;
    }

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hWnd, message, wParam, lParam);
}


void FullScreen()
{

}
void enforceResolution(int edge, RECT& rt, int win_border_width, int win_border_height)
{

}

HBRUSH updateColor(WPARAM wParam, LPARAM lParam)
{
    HDC hdc = (HDC)wParam;
    HWND hwnd = (HWND)lParam;

    float cr, cg, cb, ca;

    cr = 255.f;
    cg = 0.0f;
    cb = 255.f;
    ca = 255.f;
#if 1
    float br, bg, bb, ba;

    br = 0.0f;
    bg = 0.0f;
    bb = 255.f;
    ba = 255.f;

    SetTextColor(hdc, RGB(cr, cg, cb));
    COLORREF color = RGB(br, bg, bb);
    SetBkColor(hdc, color);

    return CreateSolidBrush(color);
#endif
    return 0;
}


//==================================================================
// Monster Editor
//==================================================================

static iArray* arrayMonster;
Monster* dummyMonster;

HWND* hWndStatic;
HWND* hWndBtn;
HWND hWndLB;
HWND hWndCB;

void initMonEditor()
{
    //추가, 삭제, 저장, 로드 문구
    hWndStatic = new HWND[3]; 
    hWndBtn = new HWND[4];

    const char* st_str[3] = {
        "공격력", "방어력", "체력"
    };
    for (int i = 0; i < 3; i++)
    {
        hWndStatic[i] = createWndStatic(st_str[i], (i % 2 * 210), 100 + (i / 2 * 35), 100, 30, updateColor);
    }

    const char* strBtnName[4] = { "추가" , "삭제" , "저장", "로드"};
    for (int i = 0; i < 4; i++)
        hWndBtn[i] = createWndButton(strBtnName[i], 3 + 55 * i, 3, 50, 30);
       
}

//
// For WM_COMMAND
//

void updateMonster(WPARAM wParam, LPARAM lParam)
{
    HWND hwnd = (HWND)lParam;
    for (int i = 0; i < 4; i++)
    {
        if (hwnd == hWndBtn[i])
        {
            printf("push Bnt\n");
            break;
        }
    }

    HWND hwnd = (HWND)lParam;
}