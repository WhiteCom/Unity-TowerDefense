#pragma once

#include "iHeader.h"

#include "MonWindow.h"
#include "Monster.h"


#include "../resource.h"

extern bool runWnd;

#ifdef _DEBUG
#pragma comment(linker, "/entry:wWinMainCRTStartup /subsystem:console")
#else
#pragma comment(linker, "/entry:WinMainCRTStartup /subsystem:console")
#endif

void FullScreen();
void updateWindow();
void enforceResolution(int edge, RECT& rt, int win_border_width, int win_border_height);

void initMonEditor();


#if 1 //Not Completed
void freeMonster(void* parm);
void lbMonster();
void addMonster();
void delMonster();
void saveMonster();// hWndBtnMonster[2]
void callMonster();
void updateMonster(WPARAM wParam, LPARAM lParam); 
// WM_COMMAND 에서 사용 HWND 변수를 사용할때 왔다갔다 하지 않기 위함.

#endif