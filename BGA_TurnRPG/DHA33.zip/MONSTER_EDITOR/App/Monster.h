#pragma once

#include "iHeader.h"

enum Skill {
	FirstSkill = 0,
	SecondSkill,
	ThirdSkill,
	ForthSkill,

	skillNum
};

struct Monster
{
	char* name = NULL;
	int atk, dp, hp; //공격, 방어, 체력

	Skill skill; //스킬
	
};

